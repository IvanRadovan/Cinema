import se.nackademin.cinema.CinemaExe;

public class Main {


    public static void main(String[] args) {


        CinemaExe.run();
    }
}
